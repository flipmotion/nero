$(document).ready(function() {
	$('[data-item="slider"]').owlCarousel({
		loop:true,
		margin:0,
		nav:false,
		dots:true,
		items:1
	});
});